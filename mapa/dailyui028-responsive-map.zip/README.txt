A Pen created at CodePen.io. You can find this one at http://codepen.io/arianalynn/pen/MypjbP.

 A map for websites and 'contact us' cards!